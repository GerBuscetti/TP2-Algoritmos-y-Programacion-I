#include <stdio.h>
#include "test_de_personalidad.h"
#include "osos_contra_reloj.h"
#include "utiles.h"
#include "time.h"

#define DERECHA 'D'
#define IZQUIERDA 'A'
#define ABAJO 'S'
#define ARRIBA 'W'
#define VELA 'V'
#define BENGALA 'E'
#define LINTERNA 'L'
#define TIEMPO 'T'
#define EMPEZAR 'Q'


void ingresar_jugada(char* ultimo_movimiento, char* jugada, coordenada_t posicion){
	
	printf("Utiliza los comandos W(arriba),A(izquierda),S(abajo),D(derecha) para desplazarte por el mapa. Para utilizar las bengalas presiona E, para utlizar las velas presiona V, y para utilizar la linterna presiona L\n");
    scanf(" %c",&*jugada);
    while ((*jugada != ARRIBA) && (*jugada != IZQUIERDA) && (*jugada != ABAJO) && (*jugada != DERECHA) && (*jugada != LINTERNA) && (*jugada != VELA) && (*jugada != BENGALA) && (*jugada != TIEMPO)){
       printf("jugada incorrecta\n");
       scanf(" %c",&*jugada);
    }
        if (((*jugada == ARRIBA) && (posicion.fil > 0)) || ((*jugada == IZQUIERDA) && (posicion.col > 0)) || ((*jugada == ABAJO) && (posicion.fil < 20)) || ((*jugada == DERECHA) && (posicion.col < 30))){
    	
           *ultimo_movimiento = *jugada;
        }
}
void mensaje_ganaste(){

  printf(" \
 ▄▄▄▄▄▄▄▄▄▄▄  ▄▄▄▄▄▄▄▄▄▄▄  ▄▄        ▄  ▄▄▄▄▄▄▄▄▄▄▄  ▄▄▄▄▄▄▄▄▄▄▄  ▄▄▄▄▄▄▄▄▄▄▄  ▄▄▄▄▄▄▄▄▄▄▄ \n \
▐░░░░░░░░░░░▌▐░░░░░░░░░░░▌▐░░▌      ▐░▌▐░░░░░░░░░░░▌▐░░░░░░░░░░░▌▐░░░░░░░░░░░▌▐░░░░░░░░░░░▌\n \
▐░█▀▀▀▀▀▀▀▀▀ ▐░█▀▀▀▀▀▀▀█░▌▐░▌░▌     ▐░▌▐░█▀▀▀▀▀▀▀█░▌▐░█▀▀▀▀▀▀▀▀▀  ▀▀▀▀█░█▀▀▀▀ ▐░█▀▀▀▀▀▀▀▀▀ \n \
▐░▌          ▐░▌       ▐░▌▐░▌▐░▌    ▐░▌▐░▌       ▐░▌▐░▌               ▐░▌     ▐░▌          \n \
▐░▌ ▄▄▄▄▄▄▄▄ ▐░█▄▄▄▄▄▄▄█░▌▐░▌ ▐░▌   ▐░▌▐░█▄▄▄▄▄▄▄█░▌▐░█▄▄▄▄▄▄▄▄▄      ▐░▌     ▐░█▄▄▄▄▄▄▄▄▄ \n \
▐░▌▐░░░░░░░░▌▐░░░░░░░░░░░▌▐░▌  ▐░▌  ▐░▌▐░░░░░░░░░░░▌▐░░░░░░░░░░░▌     ▐░▌     ▐░░░░░░░░░░░▌\n \
▐░▌ ▀▀▀▀▀▀█░▌▐░█▀▀▀▀▀▀▀█░▌▐░▌   ▐░▌ ▐░▌▐░█▀▀▀▀▀▀▀█░▌ ▀▀▀▀▀▀▀▀▀█░▌     ▐░▌     ▐░█▀▀▀▀▀▀▀▀▀ \n \
▐░▌       ▐░▌▐░▌       ▐░▌▐░▌    ▐░▌▐░▌▐░▌       ▐░▌          ▐░▌     ▐░▌     ▐░▌          \n \
▐░█▄▄▄▄▄▄▄█░▌▐░▌       ▐░▌▐░▌     ▐░▐░▌▐░▌       ▐░▌ ▄▄▄▄▄▄▄▄▄█░▌     ▐░▌     ▐░█▄▄▄▄▄▄▄▄▄ \n \
▐░░░░░░░░░░░▌▐░▌       ▐░▌▐░▌      ▐░░▌▐░▌       ▐░▌▐░░░░░░░░░░░▌     ▐░▌     ▐░░░░░░░░░░░▌\n \
 ▀▀▀▀▀▀▀▀▀▀▀  ▀         ▀  ▀        ▀▀  ▀         ▀  ▀▀▀▀▀▀▀▀▀▀▀       ▀       ▀▀▀▀▀▀▀▀▀▀▀ \n \
                                                                                           \n");

}
void mensaje_perdiste(){

  printf(" \
  ▄███████▄    ▄████████    ▄████████ ████████▄   ▄█     ▄████████     ███        ▄████████ \n \
  ███    ███   ███    ███   ███    ███ ███   ▀███ ███    ███    ███ ▀█████████▄   ███    ███\n \
  ███    ███   ███    █▀    ███    ███ ███    ███ ███▌   ███    █▀     ▀███▀▀██   ███    █▀ \n \
  ███    ███  ▄███▄▄▄      ▄███▄▄▄▄██▀ ███    ███ ███▌   ███            ███   ▀  ▄███▄▄▄    \n \
▀█████████▀  ▀▀███▀▀▀     ▀▀███▀▀▀▀▀   ███    ███ ███▌ ▀███████████     ███     ▀▀███▀▀▀    \n \
  ███          ███    █▄  ▀███████████ ███    ███ ███           ███     ███       ███    █▄ \n \
  ███          ███    ███   ███    ███ ███   ▄███ ███     ▄█    ███     ███       ███    ███\n \
 ▄████▀        ██████████   ███    ███ ████████▀  █▀    ▄████████▀     ▄████▀     ██████████\n \
                            ███    ███\n");                                                     

}
    

int main(){
	
	char jugada;
	juego_t juego;
  double tiempo_total_perdido;
	srand((unsigned int) time(NULL));
 	char personalidad_detectada;
 	test_de_personalidad(&personalidad_detectada);
  system("clear");
 	printf( " tu personaje segun tu personalidad es = %c\n" ,personalidad_detectada);
 	inicializar_juego(&juego, personalidad_detectada);
  printf("Para iniciar el juego, ingresa Q\n");
  scanf(" %c",&jugada);
  while(jugada != EMPEZAR){
    printf("Para iniciar el juego, ingresa Q\n");
    scanf(" %c",&jugada);
  }
  system("clear");
  juego.personaje.ultimo_movimiento = DERECHA;
  printf("\n");
  mostrar_juego(juego);
  iniciar_cronometro();
  
 	while (estado_juego(juego) != -1){

 		ingresar_jugada(&juego.personaje.ultimo_movimiento, &jugada, juego.personaje.posicion);
    system("clear");
 		if(es_jugada_valida(jugada) == true){
      realizar_jugada(&juego, jugada);
      mostrar_juego(juego);       
 		}
    estado_juego(juego);
    
  }
  tiempo_total_perdido = detener_cronometro();

  if(tiempo_total_perdido <= 120){
    
    mensaje_ganaste();
    printf("Encontraste a chloe en un tiempo total de %f segundos\n",tiempo_total_perdido);
  }else{

    mensaje_perdiste();
    printf("Tardaste un total de %f segundos, pero tu amiga chloe ya esta con vos\nseguro se pierde devuelta y la encontras mas rapido la proxima vez!",tiempo_total_perdido);
  }


 	

}

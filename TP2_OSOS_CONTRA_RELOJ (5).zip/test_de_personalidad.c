#include <stdio.h>
#include "test_de_personalidad.h"






const int PISO_MAXIMO=18;
const int PISO_MINIMO=1;
const int GRITO_MAXIMO=18;
const int GRITO_MINIMO=1;
const int RANGO_MINIMO_POLAR=5;
const int RANGO_MAXIMO_POLAR=24;
const int RANGO_MINIMO_PARDO=44;
const int RANGO_MAXIMO_PARDO=63;
const int RANGO_MINIMO_PANDA=25;
const int RANGO_MAXIMO_PANDA=43;
const int VALOR_CANAL_A=2;
const int VALOR_CANAL_M=3;
const int VALOR_CANAL_L=1;
const int VALOR_VIANDA_B=6;
const int VALOR_VIANDA_P=9;
const int VALOR_VIANDA_F=3;
#define CANAL_ANIME 'A'
#define CANAL_LIMPIEZA 'L'
#define CANAL_MUSICAPOP 'M'
#define VIANDA_PESCADO 'P'
#define VIANDA_BAMBU 'B'
#define VIANDA_FOCA 'F'

 //devuelve en pantalla el mensaje inicial sobre de que trata el test de personalidad.
 void mensaje_inicial(){

   printf("Los escandalosos son 3 osos(pardo, panda y polar).Pardo fue rescatado de un arbol por un guardaparques,Panda escapo del cautiverio en china y Polar escapo del artico ruso al ser perseguido por unos cazadores.Cada uno de estos osos tiene una personalidad diferente la cual podras saber a cual te pareces mas haciendo este test de personalidad\nEstas a punto de ser evaluado en un test de personalidad, responde las siguientes preguntas de acuerdo a lo que harias.\n");
 }
  
//evalua el dato ingresado por el usuario y verifica que este dentro de las opciones validas.
//al ingresarse una opcion valida, queda registrado ese mismo valor.
 void registrar_canal(char *canal_elegido){

  printf("Estas aburrido y te vas a ver television un rato, pones el canal de:\nA=Anime\nM=Musicapop\nL=Limpieza\nEscribi tu respuesta a continuacion con la letra correspondiente\n");
    scanf(" %c",&*canal_elegido);

    while((*canal_elegido!=CANAL_ANIME) && (*canal_elegido!=CANAL_MUSICAPOP) && (*canal_elegido!=CANAL_LIMPIEZA)){
     printf("Error!, la opcion que ingresaste no es valida, revisa bien las mayusculas y que este dentro de las opciones posibles, volve a escribir tu respuesta\n");

     scanf(" %c" ,&*canal_elegido);
    }
 }
 //recibe la opcion del canal valida ingresada previamente.
 //evalua la opcion elegida y devuelve el puntaje obtenido por seleccionar dicha opcion.
 int puntaje_canal(char canal_elegido){
    int puntaje_canal=0;

    switch(canal_elegido){
      case CANAL_ANIME:
    puntaje_canal=puntaje_canal+VALOR_CANAL_A;
    break;
        case CANAL_MUSICAPOP:
    puntaje_canal=puntaje_canal+VALOR_CANAL_M;
    break;
        case CANAL_LIMPIEZA:
    puntaje_canal=puntaje_canal+VALOR_CANAL_L;
    break;
    }
    return puntaje_canal;
  }
  
 
  //evalua el dato ingresado por el usuario y verifica si esta dentro de las opciones validas.
  //al ingresarse una opcion valida, queda registrado el valor.
  void registrar_vianda(char *vianda_elegida){

    printf("vas a hacer un viaje de 24hs y necesitas armar tu vianda pero solo poder llevar uno de los siguientes alimentos:\nB=Bambu\nP=Pescado\nF=Focas\nEscribi tu respuesta a continuacion con la letra correspondiente\n");
    scanf(" %c",&*vianda_elegida);

    while((*vianda_elegida!=VIANDA_BAMBU) && (*vianda_elegida!=VIANDA_PESCADO) && (*vianda_elegida!=VIANDA_FOCA)){
     printf("Error!, la opcion que ingresaste no es valida, revisa bien las mayusculas y que este dentro de las opciones posibles, volve a escribir tu respuesta\n");

     scanf(" %c" ,&*vianda_elegida);
    }
  }
  //recibe la opcion de vianda valida ingresada previamente.
  //evalua la opcion elegida y devuelve el puntaje obtenido por seleccionar dicha opcion.
  int puntaje_vianda(char vianda_elegida){
    int puntaje_vianda=0;

    switch(vianda_elegida){
      case VIANDA_BAMBU:
    puntaje_vianda=puntaje_vianda+VALOR_VIANDA_B;
    break;
        case VIANDA_PESCADO:
    puntaje_vianda=puntaje_vianda+VALOR_VIANDA_P;
    break;
        case VIANDA_FOCA:
    puntaje_vianda=puntaje_vianda+VALOR_VIANDA_F;
    break;
    }
    return puntaje_vianda;
  }
  
  //se ingresa el valor de el piso y evalua si lo ingresado esta entre las opciones validas.
  //devuelve el valor del piso elegido.
  void elegir_piso(int *piso){

     printf("Tuviste suerte y ganaste la loteria, ahora vas a comprarte una torre de 18 pisos con tus 2 hermanos!,¿que piso elegis?\nEscribi tu respuesta a continuacion con el numero correspondiente\n");
     scanf(" %i" ,&*piso);

     while((*piso<PISO_MINIMO) || (*piso>PISO_MAXIMO)){
      printf("Error!, la opcion que ingresaste no es valida, revisa bien que el numero elegido este dentro de las opciones posibles, volve a escribir tu respuesta\n");

      scanf(" %i" ,&*piso);
     }
     
     
  }
  //se ingresa el valor de el grito y evalua si lo ingresado esta entre las opciones validas.
  //devuelve el puntaje de el grito elegido.
  void puntaje_grito(int *grito){

     printf("Estas disfrutando de tu vida de oso y derrepente se te cruza una rata, ¿que tan fuerte gritas en una escala del 1 al 18?\nEscribi tu respuesta a continuacio con el numero correspondiente\n");
     scanf(" %i" ,&*grito);

     while((*grito<GRITO_MINIMO) || (*grito>GRITO_MAXIMO)){
      printf("Error!, la opcion que ingresaste no es valida, revisa bien que el numero elegido este dentro de las opciones posibles, volve a escribir tu respuesta\n");

      scanf(" %i" ,&*grito);
     }
     
     
  }
  //recibe los puntajes de cada pregunta.
  //obtiene el puntaje total y imprime en pantalla el resultado de el test.

  void resultado_final(int puntaje_canal_total, int puntaje_vianda_total, int elegir_piso_final, int puntaje_grito_final, char *personalidad_evaluada){
     int puntaje_total;

     
     puntaje_total=(puntaje_canal_total*puntaje_vianda_total)+elegir_piso_final+puntaje_grito_final;
     printf("obtuviste un puntaje total de %i\n", puntaje_total);

     if((puntaje_total>=RANGO_MINIMO_POLAR) && (puntaje_total<=RANGO_MAXIMO_POLAR)){
      printf("definitivamente tenes la personalidad de oso - Polar (I) - ,frio,callado,responsable, maduro, valiente.\n");
      *personalidad_evaluada = 'I';
     }  
        else 
        if((puntaje_total>=RANGO_MINIMO_PANDA) && (puntaje_total<=RANGO_MAXIMO_PANDA)){
        printf("WOW!, tenes la personalidad de oso - Panda (P) - ,inseguro,sensible,se enamora rapido, tierno,vegetariano.\n");
        *personalidad_evaluada = 'P';
        
          }
     else{
       if((puntaje_total>=RANGO_MINIMO_PARDO) && (puntaje_total<=RANGO_MAXIMO_PARDO)){
        printf("tu personalidad se asemeja a la de oso - Pardo (G) - ,lider, hiperactivo,ruidoso, alegre, optimista,sociable, celoso.\n");
        *personalidad_evaluada = 'G';
       }
     }
   }   
 
 void test_de_personalidad(char* personalidad_detectada){
       char dato_personalidad_detectada;
       char canal;
       char vianda;
       int piso;
       int grito;
       int puntaje_canal_final;
       int puntaje_vianda_final;
       int elegir_piso_final;
       int puntaje_grito_final;
       mensaje_inicial();
       registrar_canal(&canal);
       puntaje_canal(canal);
       registrar_vianda(&vianda);
       puntaje_vianda(vianda);
       elegir_piso(&piso);
       puntaje_grito(&grito);
       puntaje_canal_final=puntaje_canal(canal);
       puntaje_vianda_final=puntaje_vianda(vianda);
       elegir_piso_final=piso;
       puntaje_grito_final=grito;
       resultado_final(puntaje_canal_final, puntaje_vianda_final, elegir_piso_final, puntaje_grito_final, &dato_personalidad_detectada);
       *personalidad_detectada = dato_personalidad_detectada;
}


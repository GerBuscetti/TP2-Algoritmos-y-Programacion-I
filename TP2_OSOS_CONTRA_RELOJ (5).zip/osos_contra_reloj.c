#include <stdio.h>
#include <stdlib.h> 
#include <stdbool.h>
#include <time.h>
#include <string.h>
#include "utiles.h"
#include "osos_contra_reloj.h"



#define DERECHA 'D'
#define IZQUIERDA 'A'
#define ABAJO 'S'
#define ARRIBA 'W'
#define VELA 'V'
#define BENGALA 'E'
#define PILA 'B'
#define KOALA 'K'
#define ARBOL 'A'
#define PIEDRA 'R'
#define LINTERNA 'L'
#define TIEMPO 'T'
#define POLAR 'I'
#define PARDO 'G'
#define PANDA 'P'
#define CHLOE 'C'
#define NIEBLA '+'
#define EMOJI_ARBOL "\U0001f332"
#define EMOJI_PIEDRA "\U0001f5ff"
#define EMOJI_KOALA "\U0001f428"
#define EMOJI_PANDA "\U0001f43c"
#define EMOJI_PARDO "\U0001f43b"
#define EMOJI_POLAR "\U0001f43b"
#define EMOJI_PILA "\U0001f50b"
#define EMOJI_VELA "\U0001f3ee"
#define EMOJI_BENGALA "\U0001f4cd"
#define EMOJI_CHLOE "\U0001f467"
#define EMOJI_NIEBLA "\U0001f30c"

const int LINTERNA_EN_USO = 0;
const int MAX_FILAS = 20;
const int MAX_COLUMNAS = 30;
const int MAX_POSICIONES = 600;
const int ELEMENTOS_SIN_USAR = -1;
const int LIMITE_DERECHO = 29;
const int LIMITE_IZQUIERDO = 0;
const int LIMITE_SUPERIOR = 0;
const int LIMITE_INFERIOR = 19;
const int HABILIDAD_PANDA_ACTIVA = 30;

void mensaje_bienvenida(){
	

	 printf(" \
Chloe%s park es una niña que un dia se colo en la cueva de los osos escandalosos para investigar\n \
y juntar informacion para su trabajo universitario.\n \
Con el tiempo estos 4 se hicieron muy amigos, disfrutando jugar dia a dia juntos.\n \
Un dia, estos deciden jugar a las escondidas, pero se olvidaron de que hay toque de queda!.\n \
Chloe sigue escondida en el bosque, es de noche y hay mucha niebla,tu objetivo sera ayudar a tu oso a encontrarla\n \
 antes de que pase el horario del toque de queda.\n \
El juego muestra un mapa del bosque con la posicion de tu personaje, con el cual\n \
te desplazaras en busca de chloe.\n \
Para ganar el juego deberas encontrar a Chloe en menos de 120 segundos(tiempo faltante para el toque de queda).\n \
A lo largo del juego podes encontrarte con obstaculos(ARBOLES%s, PIEDRAS%s, KOALAS%s) que restaran tiempo para encontrar\n \
a Chloe antes del toque de queda.\n \
Las piedras suman 2 segundos al tiempo perdido, excepto a Polar que tiene la habilidad de evadirlas.\n \
Los arboles suman 1 segundo al tiempo perdido, excepto a Pardo, que solo sumara 0,5 segundos\n \
Los koalas no te restaran tiempo pero te devolveran al inicio del bosque.\n \
Para encontrar a Chloe con mas facilidad, se disponen de 3 tipos de herramientas(LINTERNA,VELA%s, BENGALA%s ):\n \
-LINTERNA: Ilumina la fila completa y empieza con 10 usos de durabilidad, excepto a PARDO%s\n \
que es experto en acampar y andar de noche, por lo tanto empieza con 15 usos de durabilidad.\n \
Cada vez que la linterna es prendida aparece un nuevo koala en el bosque.\n \
-VELA: Ilumina los espacios alrededor del personaje, se inicia con 4 velas en la mochila\n \
a excepcion de POLAR%s que empieza con 6 velas en su mochila gracias a que le gusta hacer yoga y\n \
siempre tiene velas demas.\n \
-BENGALA: Es lanzada hacia una ubicacion aleatoria e ilumina cada posicion que esta a una distancia de 3 bloques o menos.\n \
Las bengalas y las velas pueden ser encontradas a lo largo del bosque y se sumaran a tu mochila al pararte sobre ellas, asi las\n \
tendras disponibles para su uso.PANDA%scomienza con 2 bengalas en su mochila.Tambien habra PILAS(%s) que podras juntar para recargarle 5 movimientos a tu linterna.\n \
Todas las herramientas tienen el poder de quitar la niebla!\n \
Los comandos disponibles son:\n \
-W:Desplazarse hacia arriba\n \
-A:Desplazarse hacia la izquierda\n \
-S:Desplazarse hacia abajo\n \
-D:Desplazarse hacia la derecha\n \
-T:Mostrar el tiempo perdido por los obstaculos que chocaste y\n \
el tiempo transcurrido desde que empezo el juego\n-L:Activas o desactivas la linterna\n \
-V:Prender una vela\n \
-E:Usar una bengala\n",EMOJI_CHLOE, EMOJI_ARBOL, EMOJI_PIEDRA, EMOJI_KOALA, EMOJI_VELA, EMOJI_BENGALA,EMOJI_PARDO, EMOJI_POLAR,EMOJI_PANDA, EMOJI_PILA);
}

//PRE: Recibe la estructura del personaje.
//POST: Devuelve la mochila con la linterna, inicializada con 15 movimientos a usar por tener a Pardo como personaje.
void inicializar_linterna_pardo(personaje_t* personaje){
    
    personaje->mochila[personaje->cantidad_elementos].tipo = LINTERNA;
    personaje->mochila[personaje->cantidad_elementos].movimientos_restantes = 15;
    personaje->cantidad_elementos++;
         
}
//PRE: Recibe la estructura del personaje.
//POST: Devuelve la mochila con 6 velas agregadas por tener a Polar como personaje.
void inicializar_velas_polar(personaje_t* personaje){
    
    while (personaje->cantidad_elementos < 7){
        personaje->mochila[personaje->cantidad_elementos].tipo = VELA;
        personaje->mochila[personaje->cantidad_elementos].movimientos_restantes = 5;
        personaje->cantidad_elementos++;     
    }
}
//PRE: Recibe la estructura del personaje.
//POST: Devuelve la mochila con la linterna, inicializada con 10 movimientos a usar.
void inicializar_linterna_mochila(personaje_t* personaje){
    
    personaje->mochila[personaje->cantidad_elementos].tipo = LINTERNA;
    personaje->mochila[personaje->cantidad_elementos].movimientos_restantes = 10;
    personaje->cantidad_elementos++;
}
//PRE: Recibe la estructura del personaje.
//POST: Devuelve la mochila con 4 velas agregadas.
void inicializar_velas_mochila(personaje_t* personaje){
    
    while (personaje->cantidad_elementos < 5){
        personaje->mochila[personaje->cantidad_elementos].tipo = VELA;
        personaje->mochila[personaje->cantidad_elementos].movimientos_restantes = 5;
        personaje->cantidad_elementos++;
    }
}
//PRE: Recibe la estructura del personaje.
//POST: Devuelve la mochila con 2 bengalas a usar por tener a Panda como personaje.
void inicializar_bengalas_panda(personaje_t* personaje){

	while (personaje->cantidad_elementos < 7){
        personaje->mochila[personaje->cantidad_elementos].tipo = BENGALA;
        personaje->mochila[personaje->cantidad_elementos].movimientos_restantes = 5;
        personaje->cantidad_elementos++;
    }
}
//PRE: Recibe la estructura del personaje y su tipo de personaje.
//POST: Devuelve la estructura del personaje inicializada.
void inicializar_personaje(personaje_t* personaje, char tipo_personaje){

	personaje->cantidad_elementos = 0;
    personaje->posicion.fil = rand() %MAX_FILAS;   
    personaje->posicion.col = 0;
    personaje->tipo = tipo_personaje;
    personaje->tiempo_perdido = 0;
    personaje->elemento_en_uso = ELEMENTOS_SIN_USAR;
   
    if (personaje->tipo == PARDO){
    	inicializar_linterna_pardo(&*personaje);	
    }else{	
        inicializar_linterna_mochila(&*personaje);
    }
    if (personaje->tipo == POLAR){
    	inicializar_velas_polar(&*personaje);    	
    }else{
    	inicializar_velas_mochila(&*personaje);
    } 
    if (personaje->tipo == PANDA){ 
        inicializar_bengalas_panda(&*personaje);
    }   
}
//PRE: Recibe la posicion del personaje junto a los datos de Chloe.
//POST: Devuelve a chloe inicializada. 
void posicionar_chloe(coordenada_t* amiga_chloe, bool* chloe_visible, coordenada_t posicion){
    
	amiga_chloe->fil = rand() %MAX_FILAS;
	amiga_chloe->col = rand() %MAX_COLUMNAS;

	while ((amiga_chloe->fil == posicion.fil) && (amiga_chloe->col == posicion.col)){

	  amiga_chloe->fil = rand() %MAX_FILAS;
	  amiga_chloe->col = rand() %MAX_COLUMNAS;
	}
	
	*chloe_visible = false;
}
	
//PRE: Recibe el vector de obstaculos.
//POST: Devuelve true si la posicion a evaluar es valida, false caso contrario. 
bool validar_obstaculo_con_obstaculos(elemento_del_mapa_t obstaculos[MAX_OBSTACULOS], int cantidad_obstaculos){
	int obstaculo_a_chequear = 0;
	bool posicion_valida = true;
	while((obstaculo_a_chequear < cantidad_obstaculos) && (posicion_valida == true)){

	 	if((obstaculos[cantidad_obstaculos].posicion.fil != obstaculos[obstaculo_a_chequear].posicion.fil) || (obstaculos[cantidad_obstaculos].posicion.col != obstaculos[obstaculo_a_chequear].posicion.col)){
		  
		    obstaculo_a_chequear++;	

		}else{

		    posicion_valida = false;
	    }
	}
return posicion_valida;
}
	
//PRE: Recibe el vector de herramientas y obstaculos.
//POST: Devuelve true si la posicion a evaluar es valida, false caso contrario.
bool validar_obstaculo_con_herramientas(elemento_del_mapa_t obstaculos[MAX_OBSTACULOS], elemento_del_mapa_t herramientas[MAX_HERRAMIENTAS], int cantidad_herramientas, int cantidad_obstaculos){
	int herramienta_a_chequear = 0;
	bool posicion_valida = true;
	while ((herramienta_a_chequear < cantidad_herramientas) && (posicion_valida == true)){

	 	if((obstaculos[cantidad_obstaculos].posicion.fil != herramientas[herramienta_a_chequear].posicion.fil) || (obstaculos[cantidad_obstaculos].posicion.col != herramientas[herramienta_a_chequear].posicion.col)){
		  
		    herramienta_a_chequear++;
		        
		}else{

		    posicion_valida = false;
	    }
	}
return posicion_valida;

}
//PRE: Recibe el vector de obstaculos.
//POST: Devuelve true si la posicion a evaluar es valida, false caso contrario.
bool validar_obstaculo_con_personajeychloe(elemento_del_mapa_t obstaculos[MAX_OBSTACULOS], int cantidad_obstaculos, coordenada_t posicion, coordenada_t amiga_chloe){

    bool posicion_valida = false;
    if ((obstaculos[cantidad_obstaculos].posicion.fil != posicion.fil) || (obstaculos[cantidad_obstaculos].posicion.col != posicion.col)){
         	     
	    if ((obstaculos[cantidad_obstaculos].posicion.fil != amiga_chloe.fil) || (obstaculos[cantidad_obstaculos].posicion.col != amiga_chloe.col)){
           
            posicion_valida = true;
        }   
    } 
return posicion_valida;		
} 

//PRE: Recibe la estructura del juego.
//POST: Devuelve true si la posicion a evaluar es valida, false caso contrario.
bool validar_posicion_koala(juego_t* juego){
       
	bool posicion_valida;
	    
	posicion_valida = validar_obstaculo_con_obstaculos(juego->obstaculos, juego->cantidad_obstaculos);
	if(posicion_valida == true){
		posicion_valida = validar_obstaculo_con_herramientas(juego->obstaculos, juego->herramientas, juego->cantidad_herramientas, juego->cantidad_obstaculos);    
        if (posicion_valida == true){
    	    posicion_valida = validar_obstaculo_con_personajeychloe(juego->obstaculos,juego->cantidad_obstaculos, juego->personaje.posicion, juego->amiga_chloe);
    	}
    }
return posicion_valida;
}

//PRE: Recibe la estrucutra del juego.
//POST: Posiciona un koala en el mapa en una posicion valida.
void generar_koala(juego_t* juego){
    bool posicion_valida;
    juego->obstaculos[juego->cantidad_obstaculos].posicion.fil = rand() %MAX_FILAS;
	juego->obstaculos[juego->cantidad_obstaculos].posicion.col = rand() %MAX_COLUMNAS;
	posicion_valida = validar_posicion_koala(juego);
	while(posicion_valida == false){
        juego->obstaculos[juego->cantidad_obstaculos].posicion.fil = rand() %MAX_FILAS;
	    juego->obstaculos[juego->cantidad_obstaculos].posicion.col = rand() %MAX_COLUMNAS;
		posicion_valida = validar_posicion_koala(juego);

	}
	juego->obstaculos[juego->cantidad_obstaculos].tipo = KOALA;
	juego->obstaculos[juego->cantidad_obstaculos].visible = false;
	juego->cantidad_obstaculos++;

}
//PRE: Recibe la estructura de juego.
//POST: Devuelve el vector de obstaculos con los arboles inicializados.
void inicializar_arboles (juego_t* juego){

    int cantidad_arboles = 0;
    bool posicion_valida;  
	while(cantidad_arboles < 350){
        posicion_valida = false;    	    
	    while(posicion_valida == false){
	    	juego->obstaculos[juego->cantidad_obstaculos].posicion.fil = rand() %MAX_FILAS;
	    	juego->obstaculos[juego->cantidad_obstaculos].posicion.col = rand() %MAX_COLUMNAS;
	    	posicion_valida = validar_obstaculo_con_obstaculos(juego->obstaculos, juego->cantidad_obstaculos);
	    	if(posicion_valida == true){
	    		posicion_valida = validar_obstaculo_con_personajeychloe(juego->obstaculos,juego->cantidad_obstaculos, juego->personaje.posicion, juego->amiga_chloe);
	    	}
	    }
		if(posicion_valida == true){ 	
        
            juego->obstaculos[juego->cantidad_obstaculos].tipo = ARBOL;
	    	juego->obstaculos[juego->cantidad_obstaculos].visible = false;
	    	juego->cantidad_obstaculos++;
	    	cantidad_arboles++;	          
		}	
	}
}
//PRE: Recibe la estructura de juego.
//POST: Devuelve el vector de obstaculos con las piedras inicializadas.
void inicializar_piedras (juego_t* juego){
	
    int cantidad_piedras = 0;
    bool posicion_valida;  
    
	while(cantidad_piedras < 80){
        posicion_valida = false;    	    
	    while(posicion_valida == false){
	    	juego->obstaculos[juego->cantidad_obstaculos].posicion.fil = rand() %MAX_FILAS;
	    	juego->obstaculos[juego->cantidad_obstaculos].posicion.col = rand() %MAX_COLUMNAS;
	    	posicion_valida = validar_obstaculo_con_obstaculos(juego->obstaculos, juego->cantidad_obstaculos);
	    	if(posicion_valida == true){
	    		posicion_valida = validar_obstaculo_con_personajeychloe(juego->obstaculos,juego->cantidad_obstaculos, juego->personaje.posicion, juego->amiga_chloe);
	    	}
	    }
		if(posicion_valida == true){ 	
        
            juego->obstaculos[juego->cantidad_obstaculos].tipo = PIEDRA;
	    	juego->obstaculos[juego->cantidad_obstaculos].visible = false;
	    	juego->cantidad_obstaculos = juego->cantidad_obstaculos + 1;
	    	cantidad_piedras++;          
		}	
	}
}
//PRE: Recibe la estructura del juego.
//POST: Devuelve los obstaculos inicializados.
void inicializar_obstaculos (juego_t* juego){

	juego->cantidad_obstaculos = 0;
    inicializar_arboles(juego);
    inicializar_piedras(juego);
    generar_koala(juego);
	

}
//PRE: Recibe el vector de herramientas y obstaculos.
//POST: Devuelve true si la posicion a evaluar es valida, false caso contrario.
bool validar_herramienta_con_obstaculos(elemento_del_mapa_t obstaculos[MAX_OBSTACULOS], elemento_del_mapa_t herramientas[MAX_HERRAMIENTAS], int cantidad_herramientas, int cantidad_obstaculos){

	int obstaculo_a_chequear = 0;
	bool posicion_valida = true;
	while ((obstaculo_a_chequear < cantidad_obstaculos) && (posicion_valida == true)){

	 	if((herramientas[cantidad_herramientas].posicion.fil != obstaculos[obstaculo_a_chequear].posicion.fil) || (herramientas[cantidad_herramientas].posicion.col != obstaculos[obstaculo_a_chequear].posicion.col)){
		  
		    obstaculo_a_chequear++;
		         
		}else{

		    posicion_valida = false;
		       
	    }
	}
return posicion_valida;
}
//PRE: Recibe el vector de herramientas.
//POST: Devuelve true si la posicion a evaluar es valida, false caso contrario.
bool validar_herramienta_con_herramientas(elemento_del_mapa_t herramientas[MAX_HERRAMIENTAS], int cantidad_herramientas){

	int herramienta_a_chequear = 0;
	bool posicion_valida = true;
	while ((herramienta_a_chequear < cantidad_herramientas) && (posicion_valida == true)){

	 	if((herramientas[cantidad_herramientas].posicion.fil != herramientas[herramienta_a_chequear].posicion.fil) || (herramientas[cantidad_herramientas].posicion.col != herramientas[herramienta_a_chequear].posicion.col)){
		  
		    herramienta_a_chequear++;
		         
		}else{

		    posicion_valida = false;		            
	    }
 	}
return posicion_valida;
}
//PRE: Recibe el vector de herramientas.
//POST: Devuelve true si la posicion a evaluar es valida, false caso contrario.
bool validar_herramienta_con_personajeychloe(elemento_del_mapa_t herramientas[MAX_HERRAMIENTAS], int cantidad_herramientas, coordenada_t posicion, coordenada_t amiga_chloe){

	bool posicion_valida = false;
	if ((herramientas[cantidad_herramientas].posicion.fil != posicion.fil) || (herramientas[cantidad_herramientas].posicion.col != posicion.col)){
         	     
	    if ((herramientas[cantidad_herramientas].posicion.fil != amiga_chloe.fil) || (herramientas[cantidad_herramientas].posicion.col != amiga_chloe.col)){
           
            posicion_valida = true;             
        }       
    } 
return posicion_valida;
}
//PRE: Recibe la estructura del juego.
//POST: Devuelve true si la posicion a evaluar es valida, false caso contrario.
bool posicion_herramienta_valida (juego_t* juego){
	bool posicion_valida;
	                 
	posicion_valida = validar_herramienta_con_obstaculos(juego->obstaculos, juego->herramientas, juego->cantidad_herramientas, juego->cantidad_obstaculos);
	if(posicion_valida == true){
		posicion_valida = validar_herramienta_con_herramientas(juego->herramientas, juego->cantidad_herramientas);
		if(posicion_valida == true){
 			posicion_valida = validar_herramienta_con_personajeychloe(juego->herramientas,juego->cantidad_herramientas, juego->personaje.posicion, juego->amiga_chloe);
		}
	}
return posicion_valida;

}
//PRE: Recibe la estructura de juego.
//POST: Devuelve el vector de herramientas con las velas inicializadas.
void inicializar_velas(juego_t* juego){
 int cantidad_velas = 0;
 bool posicion_valida;

    while(cantidad_velas < 30){
    	posicion_valida = false;
    	while(posicion_valida == false){
    		juego->herramientas[juego->cantidad_herramientas].posicion.fil = rand() %MAX_FILAS;
	   		juego->herramientas[juego->cantidad_herramientas].posicion.col = rand() %MAX_COLUMNAS;	
    	    posicion_valida = posicion_herramienta_valida(juego);
   		}  
        juego->herramientas[juego->cantidad_herramientas].tipo = VELA;
	    juego->herramientas[juego->cantidad_herramientas].visible = false;
	    juego->cantidad_herramientas++;
	    cantidad_velas++;
	}
}
//PRE: Recibe la estructura de juego.
//POST: Devuelve el vector de herramientas con las bengalas inicializadas.
void inicializar_bengalas(juego_t* juego){
    int cantidad_bengalas = 0;
    bool posicion_valida;

	while(cantidad_bengalas < 10){
		posicion_valida = false;
	    while(posicion_valida == false){
	  		juego->herramientas[juego->cantidad_herramientas].posicion.fil = rand() %MAX_FILAS;
	    	juego->herramientas[juego->cantidad_herramientas].posicion.col = rand() %MAX_COLUMNAS;
       	    posicion_valida = posicion_herramienta_valida (juego);
        }
        juego->herramientas[juego->cantidad_herramientas].tipo = BENGALA;
	    juego->herramientas[juego->cantidad_herramientas].visible = false;
	    juego->cantidad_herramientas++;
	    cantidad_bengalas++;
	  
	}
}
//PRE: Recibe la estructura de juego.
//POST: Devuelve el vector de herramientas con las pilas inicializadas.
void inicializar_pilas(juego_t* juego){
	int cantidad_pilas = 0;
	bool posicion_valida;

	while(cantidad_pilas < 30){  
		posicion_valida = false;
	    while(posicion_valida == false){
	  		juego->herramientas[juego->cantidad_herramientas].posicion.fil = rand() %MAX_FILAS;
	    	juego->herramientas[juego->cantidad_herramientas].posicion.col = rand() %MAX_COLUMNAS;
          	posicion_valida = posicion_herramienta_valida (juego);
        } 
        juego->herramientas[juego->cantidad_herramientas].tipo = PILA;
	    juego->herramientas[juego->cantidad_herramientas].visible = false;
	    juego->cantidad_herramientas++;
	    cantidad_pilas++; 
	} 
}
//PRE: Recibe la estructura de juego.
//POST: Devuelve el vector de herramientas con las herramientas inicializadas.
void inicializar_herramientas (juego_t* juego){
      
    juego->cantidad_herramientas = 0;
    inicializar_velas(juego);
    inicializar_pilas(juego);
    inicializar_bengalas(juego);
}
//PRE: Recibe la estructura de juego.
//POST: Imprime en pantalla la situacion de chocar una piedra y suma el tiempo perdido.
void choco_piedra(juego_t* juego){

	if(juego->personaje.tipo == POLAR){

	 printf("POLAR observa una piedra\n");
					
     }else{
 	 printf("Te tropezaste con una piedra, tiempo perdido + 2\n");
 	 juego->personaje.tiempo_perdido = juego->personaje.tiempo_perdido + 2;
     }

}
//PRE: Recibe la estructura de juego.
//POST: Imprime en pantalla la situacion de chocar un arbol y suma el tiempo perdido.
void choco_arbol(juego_t* juego){
  if(juego->personaje.tipo == PARDO){

	 printf("Te chocaste contra un arbol,tiempo perdido + 0.5\n");
	 juego->personaje.tiempo_perdido = juego->personaje.tiempo_perdido + 0.5;
					
  }else{

     printf("Te chocaste contra un arbol,tiempo perdido + 1\n");
     juego->personaje.tiempo_perdido++;
   }
}
//PRE: Recibe el vector de obstaculos y posicion generada del personaje.
//POST: Devuelve true si la posicion genera es valida, false caso contrario.
bool validar_personaje_con_obstaculos(elemento_del_mapa_t obstaculos[MAX_OBSTACULOS],int cantidad_obstaculos,coordenada_t posicion){
    bool posicion_valida = true;
    int obstaculo_a_chequear = 0;
	while ((obstaculo_a_chequear < cantidad_obstaculos) && (posicion_valida == true)){

	 	     if((posicion.fil != obstaculos[obstaculo_a_chequear].posicion.fil) || (posicion.col != obstaculos[obstaculo_a_chequear].posicion.col)){
		  
		       obstaculo_a_chequear++;
		         
		     }else{
		       posicion_valida = false;
		      
	         }
	    }
return posicion_valida;
}
//PRE: Recibe el vector de herramientas y posicion generada del personaje.
//POST: Devuelve true si la posicion generada es valida, false caso contrario.
bool validar_personaje_con_herramientas(elemento_del_mapa_t herramientas[MAX_OBSTACULOS],int cantidad_herramientas,coordenada_t posicion){
    bool posicion_valida = true;
    int herramienta_a_chequear = 0;
	while ((herramienta_a_chequear < cantidad_herramientas) && (posicion_valida == true)){

	 	     if((posicion.fil != herramientas[herramienta_a_chequear].posicion.fil) || (posicion.col != herramientas[herramienta_a_chequear].posicion.col)){
		  
		       herramienta_a_chequear++;
		         
		     }else{
		       posicion_valida = false;
		      
	         }
	    }
return posicion_valida;
}
//PRE: Recibe la estructura de juego..
//POST: Devuelve true si la posicion generada es valida, false caso contrario.
bool posicion_personaje_valida(juego_t* juego){
  
    bool posicion_valida;

    juego->personaje.posicion.fil = rand() %MAX_FILAS;
    juego->personaje.posicion.col = 0;           
    posicion_valida = validar_personaje_con_obstaculos(juego->obstaculos,juego->cantidad_obstaculos,juego->personaje.posicion);  
	if(posicion_valida == true){
		posicion_valida = validar_personaje_con_herramientas(juego->herramientas,juego->cantidad_herramientas,juego->personaje.posicion);
		if(posicion_valida == true){
			if((juego->personaje.posicion.fil != juego->amiga_chloe.fil) || (juego->personaje.posicion.col != juego->amiga_chloe.col)){

            	return posicion_valida;
 		    }else{

 		  	 posicion_valida = false;
 		    }
		}
	}   
return posicion_valida; 		
}
//PRE: Recibe la estructura de juego.
//POST: Genera una nueva posicion de personaje valida en caso de chocar un koala.
void choco_koala(juego_t* juego){
  bool posicion_valida = false;
  while(posicion_valida == false){
     posicion_valida = posicion_personaje_valida(juego);
  }
 
  printf("Te encontraste con un KOALA y te hizo volver a el incio del bosque :( \n");

}

//PRE: Recibe la estructura de juego.
//POST: Suma movimientos al uso de la linterna.
void encontrar_pila(juego_t* juego){
	int elementos_verificados = 0;

    while (juego->personaje.mochila[elementos_verificados].tipo != LINTERNA){
        elementos_verificados++;
    }
	juego->personaje.mochila[elementos_verificados].movimientos_restantes = juego->personaje.mochila[elementos_verificados].movimientos_restantes + 5; 
	printf("Encontraste una pila, se suman 5 movimientos al uso de linterna\n");
    


}
//PRE: Recibe la estructura juego.
//POST: Agrega una vela a la mochila.
void encontrar_vela(juego_t* juego){
   
    juego->personaje.mochila[juego->personaje.cantidad_elementos].tipo = VELA;
    juego->personaje.mochila[juego->personaje.cantidad_elementos].movimientos_restantes = 5;
	juego->personaje.cantidad_elementos++;
    printf("Encontraste una vela y se agrego a tu mochila\n");
}
//PRE: Recibe la estructura juego.
//POST: Agrega una bengala a la mochila.
void encontrar_bengala(juego_t* juego){
    
    juego->personaje.mochila[juego->personaje.cantidad_elementos].tipo = BENGALA;
	juego->personaje.mochila[juego->personaje.cantidad_elementos].movimientos_restantes = 3;
	juego->personaje.cantidad_elementos++;
    printf("Encontraste una bengala y se agrego a tu mochila\n");

}
//PRE: Recibe la estructura de juego.
//ejecuta la accion correspondiente a cada elemento y devuelve la posicion de la herramienta encontrada y un bool true si encontro una.
void encontrar_herramienta(juego_t* juego,int* posicion_herramienta, bool* hay_herramienta){
	
	*hay_herramienta = false;
	int herramienta_a_chequear = 0;
	while ((herramienta_a_chequear < juego->cantidad_herramientas) && (*hay_herramienta == false)){

		if((juego->herramientas[herramienta_a_chequear].posicion.fil == juego->personaje.posicion.fil) && (juego->herramientas[herramienta_a_chequear].posicion.col == juego->personaje.posicion.col)){

            
			switch (juego->herramientas[herramienta_a_chequear].tipo){

				case VELA:

					encontrar_vela(juego);

				break;

				case PILA:

					encontrar_pila(juego);
					
				break;

				case BENGALA:
                     
                    encontrar_bengala(juego);
					
				break;
			
			}
			
			*hay_herramienta = true;
		}
		else{
		   herramienta_a_chequear++;
	    }
	}
	*posicion_herramienta = herramienta_a_chequear;

	
	
}
//PRE: Recibe la estructura juego y la posicion de la herramienta a eliminar.
//POST: elimina la herramienta encontrada del mapa.
void eliminar_herramienta_mapa(juego_t* juego, int posicion_herramienta){

    while(posicion_herramienta < juego->cantidad_herramientas){
    juego->herramientas[posicion_herramienta] = juego->herramientas[posicion_herramienta + 1];
    posicion_herramienta++;
    }
    juego->cantidad_herramientas--;
}
//PRE: Recibe la jugada ingresada.
//POST: Devuelve true si la jugada es valida, false caso contrario.
bool es_jugada_valida (char jugada){

   if ((jugada == 'W') || (jugada == 'A') || (jugada == 'S') || (jugada == 'D') || (jugada == 'L') || (jugada == 'V') || (jugada == 'E') || (jugada == 'T')) {

       return true;
   }else{     
       return false;
   } 
}
//PRE: Recibe las estructuras de Chloe.
//POST: Pone a Chloe visible si esta dentro del rango de la linterna.
void iluminar_chloe_arriba (coordenada_t amiga_chloe, coordenada_t posicion, bool* chloe_visible){
      
      if ((posicion.fil >= amiga_chloe.fil) && (posicion.col == amiga_chloe.col)){
         
         *chloe_visible = true;
      }
}
//PRE: Recibe las estructuras de Chloe.
//POST: Pone a Chloe visible si esta dentro del rango de la linterna.
void iluminar_chloe_izquierda (coordenada_t amiga_chloe, coordenada_t posicion, bool* chloe_visible){
      
      if ((posicion.fil == amiga_chloe.fil) && (posicion.col >= amiga_chloe.col)){
         
         *chloe_visible = true;
      }

}
//PRE: Recibe las estructuras de Chloe.
//POST: Pone a Chloe visible si esta dentro del rango de la linterna.
void iluminar_chloe_derecha (coordenada_t amiga_chloe, coordenada_t posicion, bool* chloe_visible){
      
      if ((posicion.fil == amiga_chloe.fil) && (posicion.col <= amiga_chloe.col)){
         
         *chloe_visible = true;
      }

}
//PRE: Recibe las estructuras de Chloe.
//POST: Pone a Chloe visible si esta dentro del rango de la linterna.
void iluminar_chloe_abajo (coordenada_t amiga_chloe, coordenada_t posicion, bool* chloe_visible){
      
    if ((posicion.fil <= amiga_chloe.fil) && (posicion.col == amiga_chloe.col)){
         
        *chloe_visible = true;
    }

}
//PRE: Recibe el vector de obstaculos.
//POST: Pone a los obstaculos que estan dentro del rango de la linterna visibles.
void iluminar_obstaculos_arriba (elemento_del_mapa_t obstaculos[MAX_OBSTACULOS],int cantidad_obstaculos, coordenada_t posicion){
     
    int obstaculo_a_verificar = 0;
        
    while (obstaculo_a_verificar < cantidad_obstaculos){

        if((obstaculos[obstaculo_a_verificar].posicion.fil <= posicion.fil) && (obstaculos[obstaculo_a_verificar].posicion.col == posicion.col)){

            obstaculos[obstaculo_a_verificar].visible = true; 
        }       
        obstaculo_a_verificar++;       
    }
}
//PRE: Recibe el vector de obstaculos.
//POST: Pone a los obstaculos que estan dentro del rango de la linterna visibles.
void iluminar_obstaculos_derecha (elemento_del_mapa_t obstaculos[MAX_OBSTACULOS],int cantidad_obstaculos, coordenada_t posicion){
     
     int obstaculo_a_verificar = 0;
         
    while (obstaculo_a_verificar < cantidad_obstaculos){

        if((obstaculos[obstaculo_a_verificar].posicion.fil == posicion.fil) && (obstaculos[obstaculo_a_verificar].posicion.col >= posicion.col)){

            obstaculos[obstaculo_a_verificar].visible = true;           
        }   
         obstaculo_a_verificar++;         
    }
}
//PRE: Recibe el vector de obstaculos.
//POST: Pone a los obstaculos que estan dentro del rango de la linterna visibles.
void iluminar_obstaculos_izquierda (elemento_del_mapa_t obstaculos[MAX_OBSTACULOS],int cantidad_obstaculos, coordenada_t posicion){
     
     int obstaculo_a_verificar = 0;
         
    while (obstaculo_a_verificar < cantidad_obstaculos){

        if((obstaculos[obstaculo_a_verificar].posicion.fil == posicion.fil) && (obstaculos[obstaculo_a_verificar].posicion.col <= posicion.col)){

            obstaculos[obstaculo_a_verificar].visible = true; 
        }        
        obstaculo_a_verificar++;
    }
}
//PRE: Recibe el vector de obstaculos.
//POST: Pone a los obstaculos que estan dentro del rango de la linterna visibles.
void iluminar_obstaculos_abajo (elemento_del_mapa_t obstaculos[MAX_OBSTACULOS],int cantidad_obstaculos, coordenada_t posicion){
     
     int obstaculo_a_verificar = 0;
      
    while (obstaculo_a_verificar < cantidad_obstaculos){

        if((obstaculos[obstaculo_a_verificar].posicion.fil >= posicion.fil) && (obstaculos[obstaculo_a_verificar].posicion.col == posicion.col)){

            obstaculos[obstaculo_a_verificar].visible = true; 
        }          
        obstaculo_a_verificar++;          
    }
}
//PRE: Recibe el vector de herramientas.
//POST: Pone a las herramientas que estan dentro del rango de la linterna visibles.
void iluminar_herramientas_arriba (elemento_del_mapa_t herramientas[MAX_HERRAMIENTAS],int cantidad_herramientas, coordenada_t posicion){
    
    int herramienta_a_verificar = 0;
     
    
      
    while(herramienta_a_verificar < cantidad_herramientas){

        if((herramientas[herramienta_a_verificar].posicion.fil <= posicion.fil) && (herramientas[herramienta_a_verificar].posicion.col == posicion.col)){

            herramientas[herramienta_a_verificar].visible = true; 
        }   
        herramienta_a_verificar++;  
    }
}
//PRE: Recibe el vector de herramientas.
//POST: Pone a las herramientas que estan dentro del rango de la linterna visibles.
void iluminar_herramientas_derecha (elemento_del_mapa_t herramientas[MAX_HERRAMIENTAS],int cantidad_herramientas, coordenada_t posicion){
    
    int herramienta_a_verificar = 0; 
    while(herramienta_a_verificar < cantidad_herramientas){

        if((herramientas[herramienta_a_verificar].posicion.fil == posicion.fil) && (herramientas[herramienta_a_verificar].posicion.col >= posicion.col)){

            herramientas[herramienta_a_verificar].visible = true; 
        }  
        herramienta_a_verificar++;
    }       
}
//PRE: Recibe el vector de herramientas.
//POST: Pone a las herramientas que estan dentro del rango de la linterna visibles.
void iluminar_herramientas_izquierda (elemento_del_mapa_t herramientas[MAX_HERRAMIENTAS],int cantidad_herramientas, coordenada_t posicion){
    
    int herramienta_a_verificar = 0;  
    while(herramienta_a_verificar < cantidad_herramientas){

        if((herramientas[herramienta_a_verificar].posicion.fil == posicion.fil) && (herramientas[herramienta_a_verificar].posicion.col <= posicion.col)){

            herramientas[herramienta_a_verificar].visible = true; 
        }      
        herramienta_a_verificar++;
    }
}
//PRE: Recibe el vector de herramientas.
//POST: Pone a las herramientas que estan dentro del rango de la linterna visibles.
void iluminar_herramientas_abajo (elemento_del_mapa_t herramientas[MAX_HERRAMIENTAS],int cantidad_herramientas, coordenada_t posicion){
    
    int herramienta_a_verificar = 0;
     
    
      
    while(herramienta_a_verificar < cantidad_herramientas){

        if((herramientas[herramienta_a_verificar].posicion.fil >= posicion.fil) && (herramientas[herramienta_a_verificar].posicion.col == posicion.col)){

            herramientas[herramienta_a_verificar].visible = true; 
        }  
        herramienta_a_verificar++;
    }
}
//PRE: Recibe la estructura de juego.
//POST: POne visible los obstaculos, herramientas, y a Chloe,que esten dentro del rango de la linterna
void prender_linterna(juego_t* juego){
     
    generar_koala(juego);
	juego->personaje.elemento_en_uso = LINTERNA_EN_USO;   
    switch (juego->personaje.ultimo_movimiento){

        case ARRIBA:
                 if(juego->personaje.tiempo_perdido < HABILIDAD_PANDA_ACTIVA){
                   iluminar_chloe_arriba(juego->amiga_chloe, juego->personaje.posicion,&juego->chloe_visible);
                 }
                 iluminar_obstaculos_arriba(juego->obstaculos, juego->cantidad_obstaculos, juego->personaje.posicion);
                 iluminar_herramientas_arriba(juego->herramientas, juego->cantidad_herramientas, juego->personaje.posicion);
        break;

        case IZQUIERDA:

                  if(juego->personaje.tiempo_perdido < HABILIDAD_PANDA_ACTIVA){
                    iluminar_chloe_izquierda(juego->amiga_chloe, juego->personaje.posicion,&juego->chloe_visible);
                  }
                  iluminar_obstaculos_izquierda(juego->obstaculos, juego->cantidad_obstaculos, juego->personaje.posicion);
                  iluminar_herramientas_izquierda(juego->herramientas, juego->cantidad_herramientas, juego->personaje.posicion);
        break;

        case ABAJO:

                  if(juego->personaje.tiempo_perdido < HABILIDAD_PANDA_ACTIVA){
                    iluminar_chloe_abajo(juego->amiga_chloe, juego->personaje.posicion,&juego->chloe_visible);
                  }
                  iluminar_obstaculos_abajo(juego->obstaculos, juego->cantidad_obstaculos, juego->personaje.posicion);
                  iluminar_herramientas_abajo(juego->herramientas, juego->cantidad_herramientas, juego->personaje.posicion);
        break;

        case DERECHA:

                  if(juego->personaje.tiempo_perdido < HABILIDAD_PANDA_ACTIVA){
                    iluminar_chloe_derecha(juego->amiga_chloe, juego->personaje.posicion,&juego->chloe_visible);
                  }
                  iluminar_obstaculos_derecha(juego->obstaculos, juego->cantidad_obstaculos, juego->personaje.posicion);
                  iluminar_herramientas_derecha(juego->herramientas, juego->cantidad_herramientas, juego->personaje.posicion);
        break;
    }
}
//PRE: Recibe la estructura de juego.
//POST: Pone invisibles todos los objetos del mapa.
void esconder_objetos(juego_t* juego){
   
   int apagar;
   for(apagar=0;apagar < juego->cantidad_herramientas;apagar++){
      if (juego->herramientas[apagar].visible == true){
      	juego->herramientas[apagar].visible = false;
      }
   }
   for(apagar=0;apagar < juego->cantidad_obstaculos; apagar++){
      if (juego->obstaculos[apagar].visible == true){
      	juego->obstaculos[apagar].visible = false;
      }
   }
   if(juego->personaje.tiempo_perdido < 30){
      
      juego->chloe_visible = false;
   }  
}

//PRE: Recive el vector de la mochila
//POST: Busca si hay una vela disponible en la mochila y devuelve un booleano true si la hay.
void buscar_vela_mochila(elemento_mochila_t mochila[MAX_HERRAMIENTAS],int* elemento_en_uso,int cantidad_elementos, bool* hay_herramienta){
    int herramienta_mochila = 0;
    *hay_herramienta = false;
	while((mochila[herramienta_mochila].tipo != VELA) && (herramienta_mochila < cantidad_elementos)){
        herramienta_mochila++;
    }
    if(mochila[herramienta_mochila].tipo == VELA){
		*elemento_en_uso = herramienta_mochila;
		*hay_herramienta = true;
    }
}
//PRE: Recibe el vector de herramientas.
//POST: Pone visible las herramientas en el rango de la vela.
void iluminar_herramientas_vela(elemento_del_mapa_t herramientas[MAX_HERRAMIENTAS],coordenada_t posicion, int cantidad_herramientas){

	int herramienta_a_chequear = 0;
	while(herramienta_a_chequear < cantidad_herramientas){

		if((herramientas[herramienta_a_chequear].posicion.fil >= posicion.fil - 1) && (herramientas[herramienta_a_chequear].posicion.fil <= posicion.fil + 1)){

       		if((herramientas[herramienta_a_chequear].posicion.col >= posicion.col - 1) && (herramientas[herramienta_a_chequear].posicion.col <= posicion.col + 1)){

            	herramientas[herramienta_a_chequear].visible = true;
       		}
       		if((herramientas[herramienta_a_chequear].posicion.fil == posicion.fil) && (herramientas[herramienta_a_chequear].posicion.col == posicion.col)){

       			herramientas[herramienta_a_chequear].visible = true;
       		}
       	}
        herramienta_a_chequear++;     	
    }
}
//PRE: Recibe el vector de obstaculos.
//POST: Pone visible los obstaculos en el rango de la vela.
void iluminar_obstaculos_vela(elemento_del_mapa_t obstaculos[MAX_OBSTACULOS],coordenada_t posicion, int cantidad_obstaculos){

	int obstaculo_a_chequear = 0;
	while(obstaculo_a_chequear < cantidad_obstaculos){

		if((obstaculos[obstaculo_a_chequear].posicion.fil >= posicion.fil - 1) && (obstaculos[obstaculo_a_chequear].posicion.fil <= posicion.fil + 1)){

       		if((obstaculos[obstaculo_a_chequear].posicion.col >= posicion.col - 1) && (obstaculos[obstaculo_a_chequear].posicion.col <= posicion.col + 1)){

            	obstaculos[obstaculo_a_chequear].visible = true;
       		}
       		if((obstaculos[obstaculo_a_chequear].posicion.fil == posicion.fil) && (obstaculos[obstaculo_a_chequear].posicion.col == posicion.col)){

       			obstaculos[obstaculo_a_chequear].visible = true;
       		}
       	}
        obstaculo_a_chequear++; 
    }
}
//PRE: Recibe la estructura del juego.
//POST: Pone visible los obstaculos y herramientas en la zona especificada de la vela.
void usar_vela(juego_t* juego){
	
	iluminar_obstaculos_vela(juego->obstaculos, juego->personaje.posicion, juego->cantidad_obstaculos);
	iluminar_herramientas_vela(juego->herramientas, juego->personaje.posicion,juego->cantidad_herramientas);
}

//PRE: Recibe la estructura del juego.
//POST: Siencuentra un obstaculo ejecuta la accion determinada para dicho obstaculo y devuelve un booleano en true si encontro un obstaculo.
void encontro_obstaculo(juego_t* juego, bool* hay_obstaculo){

	
	*hay_obstaculo = false;
	int obstaculo_a_chequear = 0;
	while ((obstaculo_a_chequear < juego->cantidad_obstaculos) && (*hay_obstaculo == false)){

		if((juego->obstaculos[obstaculo_a_chequear].posicion.fil == juego->personaje.posicion.fil) && (juego->obstaculos[obstaculo_a_chequear].posicion.col == juego->personaje.posicion.col)){

            
			switch (juego->obstaculos[obstaculo_a_chequear].tipo){

				case PIEDRA:

					choco_piedra(juego);

				break;

				case ARBOL:

					choco_arbol(juego);
					
				break;

				case KOALA:
				
                    if(juego->personaje.mochila[juego->personaje.elemento_en_uso].tipo == VELA){
                    	esconder_objetos(juego);
                    	choco_koala(juego);
                    	usar_vela(juego);
                    }else{
                    	choco_koala(juego);
                    }
				break;
			
			}
			
			*hay_obstaculo = true;
		}
		else{
		   obstaculo_a_chequear++;
	    }
	}	
}
//PRE: Recive el vector de la mochila.
//POST: Elimina la herramienta sin usos restantes de la mochila, excepcion con linterna que no se elimina.
void eliminar_herramienta_mochila(elemento_mochila_t mochila[MAX_HERRAMIENTAS],int elemento_en_uso, int* cantidad_elementos){
  
	while(elemento_en_uso < *cantidad_elementos){
        mochila[elemento_en_uso] = mochila[elemento_en_uso + 1];
        elemento_en_uso++;
    }
    (*cantidad_elementos)--;

}
//PRE: Recive el vector de la mochila
//POST: Busca si hay una bengala disponible en la mochila y devuelve un booleano true si la hay.
void buscar_bengala_mochila(elemento_mochila_t mochila[MAX_HERRAMIENTAS],int* elemento_en_uso,int cantidad_elementos, bool* hay_herramienta){
    int herramienta_mochila = 0;
    *hay_herramienta = false;
	while((mochila[herramienta_mochila].tipo != BENGALA) && (herramienta_mochila < cantidad_elementos)){
        herramienta_mochila++;
    }
    if(mochila[herramienta_mochila].tipo == BENGALA){
		*elemento_en_uso = herramienta_mochila;
		*hay_herramienta = true;
    }

}
int distancia_manhattan(int fil_bengala, int col_bengala, coordenada_t posicion){

    int distancia;
	distancia = (abs(fil_bengala - posicion.fil)) + (abs(col_bengala - posicion.col));
return distancia;
}
//PRE: Recive el vector de herramientas.
//POST: Pone visibles las herramientas dentro del rango de la bengala.
void iluminar_herramientas_bengala (elemento_del_mapa_t herramientas[MAX_HERRAMIENTAS],int cantidad_herramientas,int fil_bengala, int col_bengala){

	int distancia;
    int herramienta_a_chequear = 0;    
	while(herramienta_a_chequear < cantidad_herramientas){
    	
        distancia = distancia_manhattan(fil_bengala, col_bengala, herramientas[herramienta_a_chequear].posicion);
        if(distancia <= 3){
        	herramientas[herramienta_a_chequear].visible = true;
        }
        herramienta_a_chequear++;
    }
}

//PRE: Recive el vector de obstaculos.
//POST: Pone visibles los obstaculos dentro del rango de la bengala.
void iluminar_obstaculos_bengala(elemento_del_mapa_t obstaculos[MAX_OBSTACULOS],int cantidad_obstaculos, int fil_bengala, int col_bengala){

	int distancia;
    int obstaculo_a_chequear = 0;      
	while(obstaculo_a_chequear < cantidad_obstaculos){
    	
        distancia = distancia_manhattan(fil_bengala, col_bengala, obstaculos[obstaculo_a_chequear].posicion); 
        if (distancia <= 3){	
        	obstaculos[obstaculo_a_chequear].visible = true;
        }
        obstaculo_a_chequear++;
    }
}
//PRE: Recibe la estructura de juego.
//POST: Genera una posicion de la bengala e ilumina los objetos dentro del rango de la bengala
void usar_bengala(juego_t* juego){
    
	int fil_bengala = rand() %MAX_FILAS;
	int col_bengala = rand() %MAX_COLUMNAS;
	iluminar_herramientas_bengala(juego->herramientas,juego->cantidad_herramientas,fil_bengala,col_bengala);
    iluminar_obstaculos_bengala(juego->obstaculos, juego->cantidad_obstaculos, fil_bengala, col_bengala);
}
void estado_linterna(juego_t* juego){

	if(juego->personaje.mochila[juego->personaje.elemento_en_uso].tipo == LINTERNA){
        juego->personaje.mochila[juego->personaje.elemento_en_uso].movimientos_restantes--;
        if(juego->personaje.mochila[juego->personaje.elemento_en_uso].movimientos_restantes >= 0){
        printf("La linterna tiene %i usos restantes\n",juego->personaje.mochila[LINTERNA_EN_USO].movimientos_restantes);
        }
        if(juego->personaje.mochila[juego->personaje.elemento_en_uso].movimientos_restantes == -1){
       	   esconder_objetos(juego);
       	   juego->personaje.elemento_en_uso = ELEMENTOS_SIN_USAR;
       }
    }
}
//PRE: Recibe la estructura de juego.
//POST: Actualiza el estado de la bengala,restandole un movimiento y apagandola si se quedo sin usos.
void estado_bengala(juego_t* juego){

	if(juego->personaje.mochila[juego->personaje.elemento_en_uso].tipo == BENGALA){
        juego->personaje.mochila[juego->personaje.elemento_en_uso].movimientos_restantes--;
        if(juego->personaje.mochila[juego->personaje.elemento_en_uso].movimientos_restantes == -1){
       	   esconder_objetos(juego);
       	   eliminar_herramienta_mochila(juego->personaje.mochila, juego->personaje.elemento_en_uso, &juego->personaje.cantidad_elementos);
       	   juego->personaje.elemento_en_uso = ELEMENTOS_SIN_USAR;
       	}
    }
}
//PRE: Recibe la estructura de juego.
//POST: Actualiza el estado de la vela,restandole un movimiento y apagandola si se quedo sin usos.
void estado_vela(juego_t* juego){

	if(juego->personaje.mochila[juego->personaje.elemento_en_uso].tipo == VELA){
       juego->personaje.mochila[juego->personaje.elemento_en_uso].movimientos_restantes--;
        if(juego->personaje.mochila[juego->personaje.elemento_en_uso].movimientos_restantes == -1){
       	   esconder_objetos(juego);
       	   eliminar_herramienta_mochila(juego->personaje.mochila, juego->personaje.elemento_en_uso, &juego->personaje.cantidad_elementos);
       	   juego->personaje.elemento_en_uso = ELEMENTOS_SIN_USAR;
       }
    }
}
//PRE: Recibe la estructura de juego.
//POST: Actualiza el estado de la herramienta en uso.
void estado_herramientas(juego_t* juego){

	switch (juego->personaje.mochila[juego->personaje.elemento_en_uso].tipo){

		case LINTERNA:
              
            estado_linterna(juego);

		break;

		case VELA:

			estado_vela(juego);


		break;

		case BENGALA:

			estado_bengala(juego);

		break;
	}
}
//PRE: Recibe la estructura de juego.
//POST: Ejecuta la accion correspondiente a la situacion del juego.
void presionar_derecha(juego_t* juego){

	if (juego->personaje.mochila[juego->personaje.elemento_en_uso].tipo == LINTERNA){
		esconder_objetos(juego);
		prender_linterna(juego);
	}
	if (juego->personaje.posicion.col < LIMITE_DERECHO){
	 	juego->personaje.posicion.col++;
        if(juego->personaje.mochila[juego->personaje.elemento_en_uso].tipo == VELA){
			esconder_objetos(juego);
			usar_vela(juego);	 	
		}
	}else{
		printf("No podes desplazarte hacia esa direccion,llegaste a el limite del bosque!\n");
	}
}
//PRE: Recibe la estructura de juego.
//POST: Ejecuta la accion correspondiente a la situacion del juego.
void presionar_izquierda(juego_t* juego){

	if (juego->personaje.mochila[juego->personaje.elemento_en_uso].tipo == LINTERNA){
		esconder_objetos(juego);
		prender_linterna(juego);
	}
	if (juego->personaje.posicion.col > LIMITE_IZQUIERDO){
	 	juego->personaje.posicion.col--;
		if(juego->personaje.mochila[juego->personaje.elemento_en_uso].tipo == VELA){
			esconder_objetos(juego);
			usar_vela(juego);
		}	
	}else{
		printf("No podes desplazarte hacia esa direccion,llegaste a el limite del bosque!\n");
	}
}
//PRE: Recibe la estructura de juego.
//POST: Ejecuta la accion correspondiente a la situacion del juego.
void presionar_arriba(juego_t* juego){

	if (juego->personaje.mochila[juego->personaje.elemento_en_uso].tipo == LINTERNA){
		esconder_objetos(juego);
		prender_linterna(juego);
	}
	if (juego->personaje.posicion.fil > LIMITE_SUPERIOR){
		juego->personaje.posicion.fil--;
		if(juego->personaje.mochila[juego->personaje.elemento_en_uso].tipo == VELA){
			esconder_objetos(juego);
			usar_vela(juego);			    	
		}
	}else{
		printf("No podes desplazarte hacia esa direccion,llegaste a el limite del bosque!\n");
	}
}
//PRE: Recibe la estructura de juego.
//POST: Ejecuta la accion correspondiente a la situacion del juego.
void presionar_abajo(juego_t* juego){

	if (juego->personaje.mochila[juego->personaje.elemento_en_uso].tipo == LINTERNA){
		esconder_objetos(juego);
		prender_linterna(juego);
	}
	if (juego->personaje.posicion.fil < LIMITE_INFERIOR){
		juego->personaje.posicion.fil++;
		if(juego->personaje.mochila[juego->personaje.elemento_en_uso].tipo == VELA){
			esconder_objetos(juego);
			usar_vela(juego);    	
		}
	}else{
		printf("No podes desplazarte hacia esa direccion,llegaste a el limite del bosque!\n");
	}
}
//PRE: Recibe la estructura de juego.
//POST: Ejecuta la accion correspondiente a la situacion del juego.
void presionar_linterna(juego_t* juego){

	if(juego->personaje.mochila[LINTERNA_EN_USO].movimientos_restantes == 0){
        printf("Tu linterna esta agotada, busca pilas para recargarla\n");
    }
    if(juego->personaje.mochila[juego->personaje.elemento_en_uso].tipo == BENGALA){
    	printf("Bengala en uso, no podes usar la linterna hasta que se agote\n");
    }
	if((juego->personaje.elemento_en_uso != LINTERNA_EN_USO) && (juego->personaje.mochila[LINTERNA_EN_USO].movimientos_restantes > 0) && (juego->personaje.mochila[juego->personaje.elemento_en_uso].tipo != BENGALA)){
             	
        prender_linterna(juego);
	}else{

		if(juego->personaje.elemento_en_uso == LINTERNA_EN_USO){
               
            esconder_objetos(juego);
            juego->personaje.elemento_en_uso = ELEMENTOS_SIN_USAR;
        }
	}
}
//PRE: Recibe la estructura de juego.
//POST: Ejecuta la accion correspondiente a la situacion del juego.
void presionar_vela(juego_t* juego){
    
    bool hay_herramienta;
    if(juego->personaje.mochila[juego->personaje.elemento_en_uso].tipo == VELA){
    	esconder_objetos(juego);
    	juego->personaje.elemento_en_uso = ELEMENTOS_SIN_USAR;
    }else{
		if(juego->personaje.mochila[juego->personaje.elemento_en_uso].tipo != BENGALA){
        	buscar_vela_mochila(juego->personaje.mochila,&juego->personaje.elemento_en_uso,juego->personaje.cantidad_elementos,&hay_herramienta);
        	esconder_objetos(juego);
        	if(hay_herramienta == true){
           	    usar_vela(juego);
       		}else{
            	printf("No tenes velas disponibles\n");
        	}
    	}else{
        	printf("Bengala en uso,no podes utilizar otra herramenta\n");
    	}
	}
}
//PRE: Recibe la estructura de juego.
//POST: Ejecuta la accion correspondiente a la situacion del juego.
void presionar_bengala(juego_t* juego){

	bool hay_herramienta;
	if(juego->personaje.mochila[juego->personaje.elemento_en_uso].tipo != BENGALA){
        buscar_bengala_mochila(juego->personaje.mochila,&juego->personaje.elemento_en_uso,juego->personaje.cantidad_elementos,&hay_herramienta);
        if(hay_herramienta == true){
            esconder_objetos(juego);
            usar_bengala(juego);
        }else{
            printf("No tenes bengalas disponibles\n");
        }
    }else{
         printf("Ya hay una bengala en uso\n");
    }
}
//PRE: Recibe la estructura de juego y la jugada ingresada.
//POST: Ejecuta la accion correspondiente a la jugada.
void procesar_jugada(juego_t* juego, char jugada){
    
    switch (jugada){
		
		case DERECHA:

	    	presionar_derecha(juego);
		break;

		case IZQUIERDA:

			presionar_izquierda(juego);
		break;

		case ABAJO:

			presionar_abajo(juego);
		break;

		case ARRIBA:

		 	presionar_arriba(juego);
		break;

		case LINTERNA:
            
		    presionar_linterna(juego);
		break;

		case VELA:

		    presionar_vela(juego);
		break;

		case BENGALA:

			presionar_bengala(juego);
		    
		break;

		case TIEMPO:

		    printf("llevas perdiendo %f, segundos de tiempo\nTranscurrieron %f segundos desde que empezo el juego\n",juego->personaje.tiempo_perdido, tiempo_actual());
		break;
	}
}
//PRE: Recibe el vector de obstaculos y la matriz del mapa.
//Post: Devuelve la matriz del mapa con los obstaculos visibles cargados.
void cargar_obstaculos (elemento_del_mapa_t obstaculos[MAX_OBSTACULOS],int cantidad_obstaculos, char mapa[MAX_FILAS][MAX_COLUMNAS]){
  
	int obstaculo_a_verificar = 0;


	while(obstaculo_a_verificar < cantidad_obstaculos){
    	if(obstaculos[obstaculo_a_verificar].visible == true){	
        	mapa[obstaculos[obstaculo_a_verificar].posicion.fil][obstaculos[obstaculo_a_verificar].posicion.col] = obstaculos[obstaculo_a_verificar].tipo;     
        }
    obstaculo_a_verificar++;
    }
}
//PRE: Recibe el vector de herramientas y la matriz del mapa.
//Post: Devuelve la matriz del mapa con las herramientas visibles cargadas.
void cargar_herramientas (elemento_del_mapa_t herramientas[MAX_HERRAMIENTAS],int cantidad_herramientas, char mapa[MAX_FILAS][MAX_COLUMNAS]){
  
  int herramienta_a_verificar = 0;
  while(herramienta_a_verificar < cantidad_herramientas){
    if(herramientas[herramienta_a_verificar].visible == true){
      mapa[herramientas[herramienta_a_verificar].posicion.fil][herramientas[herramienta_a_verificar].posicion.col] = herramientas[herramienta_a_verificar].tipo;  
    }
    herramienta_a_verificar++;
  }
}
//PRE: Recibe las estructuras de Chloe y la matriz del mapa.
//Post: Devuelve la matriz del mapa con Chloe cargada si es visible.
void cargar_chloe (bool chloe_visible, coordenada_t amiga_chloe, char mapa[MAX_FILAS][MAX_COLUMNAS]){
  
  if(chloe_visible == true){

    mapa[amiga_chloe.fil][amiga_chloe.col] = CHLOE; 
  } 
}
//PRE: Recive la matriz del mapa.
//POST: Imprime en pantalla los objetos y personajes del juego con su respectivo emoji.
void imprimir_emojis(char mapa[MAX_FILAS][MAX_COLUMNAS],int i, int j){

	switch(mapa[i][j]){

		case ARBOL:

			printf(" %s",EMOJI_ARBOL);
		break;

		case PIEDRA:
			printf(" %s",EMOJI_PIEDRA);
		break;

		case KOALA:
			printf(" %s",EMOJI_KOALA);
		break;

		case PILA:
			printf(" %s",EMOJI_PILA);
		break;

		case VELA:
			printf(" %s",EMOJI_VELA);
		break;

		case BENGALA:
			printf(" %s",EMOJI_BENGALA);
		break;

		case PARDO:
			printf(" %s",EMOJI_PARDO);
		break;

		case PANDA:
			printf(" %s",EMOJI_PANDA);
		break;

		case POLAR:
			printf(" %s",EMOJI_POLAR);
		break;

		case CHLOE:
			printf(" %s",EMOJI_CHLOE);
		break;

		case NIEBLA:
			printf(" %s",EMOJI_NIEBLA);
		break;

	}


}
//PRE: Recibe la matriz del mapa.
//POST: Inicializa el mapa con espacios vacios.
void inicializar_mapa (char mapa[MAX_FILAS][MAX_COLUMNAS]){

	int i,j;
   
    for(i=0;i < MAX_FILAS;i++){
      
    	for(j=0;j < MAX_COLUMNAS;j++){
         
        	mapa[i][j] = NIEBLA;
        }
    }
}
//PRE: Recibe la matriz del mapa.
//POST: Imprime en pantalla el mapa.
void imprimir_mapa (char mapa[MAX_FILAS][MAX_COLUMNAS]){
	
    int i,j;    
    for(i=0;i < MAX_FILAS;i++){
      
    	for(j=0;j < MAX_COLUMNAS;j++){
   				
        	imprimir_emojis(mapa, i, j);
        }

        printf("\n");
    }  
}
/*
 * Inicializará el juego, cargando toda la información inicial
 * y los datos del personaje. 
 */
void inicializar_juego(juego_t* juego, char tipo_personaje){
	mensaje_bienvenida();
	inicializar_personaje(&juego->personaje, tipo_personaje);
	posicionar_chloe(&juego->amiga_chloe, &juego->chloe_visible, juego->personaje.posicion);
	inicializar_obstaculos(juego);
	inicializar_herramientas(juego);
}		

/*
 * Recibe un juego con todas sus estructuras válidas.
 *
 * El juego se dará por terminado, si el personaje encontró a Chloe. 
 * Devolverá:
 * -> 0 si el estado es jugando. 
 * -> -1 si el estado es terminado.
 */

int estado_juego(juego_t juego){

	if((juego.personaje.posicion.fil == juego.amiga_chloe.fil) && (juego.personaje.posicion.col == juego.amiga_chloe.col)){
	
		return -1;
	}else{
		return 0;
	}     
}
/*
 * Mueve el personaje en la dirección indicada por el usuario o habilita 
 * cualquiera de las herramientas y actualiza el juego según los elementos 
 * que haya en el camino del personaje.
 * El juego quedará en un estado válido al terminar el movimiento. 
 * El movimiento será:
 * -> W: Si el personaje debe moverse para la arriba. 
 * -> A: Si el personaje debe moverse para la izquierda.
 * -> S: Si el personaje debe moverse para la abajo.
 * -> D: Si el personaje debe moverse para la derecha.
 * -> L: Si el personaje quiere encender una linterna.
 * -> V: Si el personaje quiere encender una vela. 
 * -> E: Si el personaje quiere encender la bengala.
 * -> T: Si el personaje quiere ver el tiempo restante.
 * En caso de que querer activar una herramienta, y no tenga mas movimientos, no deberá 
 * activarse ninguna ventaja. 
 * Si se aprieta una tecla de iluminación y esta ya está siendo usada, se desactivará colocando
 * el int elemento_en_uso en -1.
 */
void realizar_jugada(juego_t* juego, char jugada){
    
    
	int posicion_herramienta;
    bool hay_obstaculo;
    bool hay_herramienta;
   
    procesar_jugada(&*juego, jugada);
    estado_herramientas(juego);  
	encontro_obstaculo(juego, &hay_obstaculo);
	if((juego->personaje.tipo == PANDA) && (juego->personaje.tiempo_perdido >= 30)){
      
      printf("Panda activa su habilidad GPS y te revela la ubicacion de chloe, fila %i, columna %i\n",juego->amiga_chloe.fil, juego->amiga_chloe.col);
      juego->chloe_visible = true;
	}
	if(hay_obstaculo == false){
      encontrar_herramienta(juego, &posicion_herramienta, &hay_herramienta);
      if(hay_herramienta == true){
        eliminar_herramienta_mapa(juego, posicion_herramienta);
	  }else{
	  	printf("\n");
	  }
    }	     
}
/*
 * Mostrará el juego por pantalla.
 * Se recomienda mostrar todo lo que sea de utilidad para el jugador.
 */
void mostrar_juego(juego_t juego){
	
	char mapa[MAX_FILAS][MAX_COLUMNAS];
	 
    inicializar_mapa(mapa);
	cargar_obstaculos(juego.obstaculos, juego.cantidad_obstaculos,mapa);
	cargar_herramientas(juego.herramientas, juego.cantidad_herramientas, mapa);
	cargar_chloe(juego.chloe_visible, juego.amiga_chloe, mapa);
	mapa[juego.personaje.posicion.fil][juego.personaje.posicion.col] = juego.personaje.tipo;
	imprimir_mapa(mapa);
	
}
 



 /* __OSOS_CONTRA_RELOJ_H__ */
#ifndef test_de_personalidad_H
#define test_de_personalidad_H
 void test_de_personalidad(char* personalidad_detectada);
#endif